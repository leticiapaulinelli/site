function showNavbar() {
    $('nav').toggleClass('responsive_nav');
}