function init() {
    if (!window.location.href.includes('erro404.html')) {
        window.location.href = './erro404.html';
    }
}
