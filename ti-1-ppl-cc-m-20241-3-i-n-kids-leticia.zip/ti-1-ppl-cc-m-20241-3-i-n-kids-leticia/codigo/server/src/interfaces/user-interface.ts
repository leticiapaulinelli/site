export interface UserInterface {
    name: string;
    phone: string;
    email: string;
    password: string;
}
