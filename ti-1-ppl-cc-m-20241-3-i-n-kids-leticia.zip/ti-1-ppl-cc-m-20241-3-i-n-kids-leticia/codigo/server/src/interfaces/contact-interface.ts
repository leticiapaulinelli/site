export interface ContactInterface {
    username: string;
    email: string;
    message: string;
}
